let seleccion=document.getElementById("seleccion");
let descripcion1= document.getElementById("descripcion");
let monto1= document.getElementById("monto");
let listaIngresos= document.getElementById("listaIngresos");
let listaEgresos= document.getElementById("listaEgresos");
let botonesBorrar = document.getElementsByClassName("borrar");
let botonCargar = document.getElementById("cargar");
let presupuesto=0;
let sumaIngresos=0;
let sumaEgresos=0;
let nuevoDescripcion;
let nuevoMonto=0;
const divDato = document.getElementsByClassName("divDato");
const ingresos = [];
const egresos = [];


console.log(ingresos);
console.log(egresos);



   
    
    





















