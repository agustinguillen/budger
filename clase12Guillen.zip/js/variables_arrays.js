let seleccion=$('#seleccion');
let descripcion1= $('#descripcion');
let monto1= $('#monto');
let listaIngresos= $('#listaIngresos');
let listaEgresos= $('#listaEgresos');
let botonesBorrar = $('#borrar');
let botonCargar = $('#cargar');
let presupuesto=0;
let sumaIngresos=0;
let sumaEgresos=0;
let nuevoDescripcion;
let nuevoMonto=0;
let db;
const divDato = $('.divDato');
let ingresos = [];
let egresos = [];
let valoresIngresos;
let valoresEgresos;
let hoy = new Date();
let dd = String(hoy.getDate()).padStart(2, '0');
let mm = String(hoy.getMonth() + 1).padStart(2, '0'); //Enero es 0!
let yyyy = hoy.getFullYear();






   
    
    





















